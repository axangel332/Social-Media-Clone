package com.example.socialmediaclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
