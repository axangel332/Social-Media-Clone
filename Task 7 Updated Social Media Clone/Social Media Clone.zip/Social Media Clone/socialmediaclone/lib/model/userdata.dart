import 'friend.dart';
import 'usercomment.dart';
import 'userpost.dart';
import 'account.dart';

class UserData {
  List<UserPost> userList = [
    UserPost(
      userimg: 'images/sumalan.jpg',
      username: 'Ariel Sulaman',
      time: '45 minutes ago',
      postcontent: 'Time is Gold',
      postimg: 'images/post1.jpg',
      numcomments: '3 comments',
      numshare: '10 shares',
      isLiked: false,
    ),
    UserPost(
      userimg: 'images/aleckssa.jpg',
      username: 'Aleckssa Oxales',
      time: '5 days ago',
      postcontent: 'My Birthday Thank you my bab!',
      postimg: 'images/post2.jpg',
      numcomments: '50 comments',
      numshare: '30 shares',
      isLiked: false,
    ),
    UserPost(
      userimg: 'images/franco.jpg',
      username: 'Franco',
      time: '2 hours ago',
      postcontent: 'Coffee ta bai!',
      postimg: 'images/post3.jpg',
      numcomments: '13 comments',
      numshare: '2 shares',
      isLiked: false,
    ),
    UserPost(
      userimg: 'images/luigi.jpg',
      username: 'Luigi',
      time: '45 minutes ago',
      postcontent: 'Hi There',
      postimg: 'images/post4.jpg',
      numcomments: '3 comments',
      numshare: '1 shares',
      isLiked: false,
    ),
  ];

  List<Friend> friendList = [
    Friend(
      img: 'images/aleckssa.jpg',
      name: 'Aleckssa Oxales',
    ),
    Friend(
      img: 'images/daryl.jpg',
      name: 'Jade Daryl Dayo',
    ),
    Friend(
      img: 'images/franco.jpg',
      name: 'Deyvis Felippe P. Franco',
    ),
    Friend(
      img: 'images/luigi.jpg',
      name: 'Luigi Ojales',
    ),
    Friend(
      img: 'images/ralph.jpg',
      name: 'Eliot Anderson',
    ),
    Friend(
      img: 'images/lablab.jpg',
      name: 'Yuri Cristino',
    ),
  ];

  List<UserComment> commentList = [
    UserComment(
      commenterImg: 'images/aleckssa.jpg',
      commenterName: 'Aleckssa Oxales',
      commentTime: '7h',
      commentContent: 'Hello Pogi!',
    ),
    UserComment(
      commenterImg: 'images/franco.jpg',
      commenterName: 'Deyvis Felippe P. Franco',
      commentTime: '3m',
      commentContent: 'What a lovely photo we got there!',
    ),
    UserComment(
      commenterImg: 'images/Luigi.jpg',
      commenterName: 'Luigi Ojales',
      commentTime: '1h',
      commentContent: 'Its the time!',
    ),
    UserComment(
      commenterImg: 'images/daryl.jpg',
      commenterName: 'Daryl Dayo',
      commentTime: '1h',
      commentContent: 'Pogi bataa!',
    ),
  ];

  Account myUserAccount = Account(
    name: 'Ariel Sumalan',
    email: 'Sumalan@gmail.com',
    img: 'images/sumalan.jpg',
    numFollowers: '4.5m',
    numPosts: '420',
    numFollowing: '630',
    numFriends: '7,920',
  );
}
