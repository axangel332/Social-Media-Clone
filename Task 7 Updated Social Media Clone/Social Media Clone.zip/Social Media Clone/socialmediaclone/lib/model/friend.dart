class Friend {
  final String img;
  final String name;
  final String? bs;
  Friend({
    required this.img,
    required this.name,
    this.bs,
  });
}
