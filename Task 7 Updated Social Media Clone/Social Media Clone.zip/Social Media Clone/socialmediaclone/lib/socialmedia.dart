import 'package:flutter/material.dart';
import 'package:socialmediaclone/model/userdata.dart';
import 'package:socialmediaclone/view/friendlist.dart';
import 'package:socialmediaclone/view/infoheader.dart';
import 'package:socialmediaclone/view/mainheader.dart';
import 'package:socialmediaclone/view/postlist.dart';

class SocialMedia extends StatefulWidget {
  const SocialMedia({super.key});

  @override
  State<SocialMedia> createState() => _SocialMediaState();
}

class _SocialMediaState extends State<SocialMedia> {
  UserData userData = UserData();

  final TextStyle followTxtStyle = const TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        shrinkWrap: true,
        children: [
          MainHeader(userData: userData),
          InfoHeader(userData: userData),
          FriendList(userData: userData),
          const SizedBox(
            height: 20,
          ), // SizedBox

          Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: Row(
              children: [
                Text('Posts', style: followTxtStyle),
              ],
            ),
          ), // Padding

          const SizedBox(
            height: 20,
          ), // SizedBox

          PostsList(userData: userData),
        ],
      ),
    );
  }
}
