import 'package:flutter/material.dart';
import 'package:socialmediaclone/model/userdata.dart';

class InfoHeader extends StatelessWidget {
  final UserData userData;

  InfoHeader({
    Key? key,
    required this.userData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final TextStyle followTxtStyle = const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
    );

    return Column(
      children: [
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text('Followers'),
            Text('Posts'),
            Text('Following'),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(
              userData.myUserAccount.numFollowers.toString(),
              style: followTxtStyle,
            ),
            Text(
              userData.myUserAccount.numPosts.toString(),
              style: followTxtStyle,
            ),
            Text(
              userData.myUserAccount.numFollowing.toString(),
              style: followTxtStyle,
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        const Divider(
          color: Colors.grey,
        ),
      ],
    );
  }
}
